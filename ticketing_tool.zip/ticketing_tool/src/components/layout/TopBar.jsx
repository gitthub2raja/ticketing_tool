import { Menu, Bell, Search } from 'lucide-react'
import { useAuth } from '../../contexts/AuthContext'

export const TopBar = ({ onMenuClick }) => {
  const { user } = useAuth()

  return (
    <header className="bg-cyber-darker/80 backdrop-blur-md border-b-2 border-cyber-neon-cyan/20 h-16 flex items-center justify-between px-4 lg:px-6 sticky top-0 z-10 shadow-lg shadow-cyber-glow-cyan/10">
      <div className="flex items-center space-x-4">
        <button
          onClick={onMenuClick}
          className="lg:hidden text-cyber-neon-cyan/70 hover:text-cyber-neon-cyan focus:outline-none transition-colors duration-300 hover:scale-110"
        >
          <Menu size={24} />
        </button>
        
        <div className="relative hidden md:block">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-cyber-neon-cyan/50 z-10" size={20} />
          <input
            type="text"
            placeholder="Search tickets..."
            className="pl-10 pr-4 py-2 bg-cyber-darker/50 border-2 border-cyber-neon-cyan/30 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyber-neon-cyan/50 focus:border-cyber-neon-cyan text-cyber-neon-cyan placeholder-cyber-neon-cyan/50 w-64 font-mono transition-all duration-300 hover:border-cyber-neon-cyan/50"
          />
        </div>
      </div>

      <div className="flex items-center space-x-4">
        <button className="relative text-cyber-neon-cyan/70 hover:text-cyber-neon-cyan focus:outline-none transition-colors duration-300 hover:scale-110">
          <Bell size={24} />
          <span className="absolute top-0 right-0 w-3 h-3 bg-red-500 rounded-full border-2 border-cyber-darker animate-pulse"></span>
        </button>
        
        <div className="flex items-center space-x-3">
          <div className="text-right hidden sm:block">
            <p className="text-sm font-cyber font-semibold text-cyber-neon-cyan">{user?.name || 'User'}</p>
            <p className="text-xs text-cyber-neon-cyan/60 font-mono">{user?.email || ''}</p>
          </div>
          <div className="w-10 h-10 bg-gradient-to-br from-cyber-neon-cyan to-cyber-neon-blue rounded-full flex items-center justify-center text-cyber-dark font-cyber font-bold glow-cyber border-2 border-cyber-neon-cyan/50">
            {user?.name?.charAt(0).toUpperCase() || 'U'}
          </div>
        </div>
      </div>
    </header>
  )
}
